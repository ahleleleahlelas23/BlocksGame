import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.util.Random;

public class BlocksGame extends eng {

    private static final int WORLD_WIDTH = 20;
    private static final int WORLD_HEIGHT = 15;
    private static final int BLOCK_SIZE = 40;

    private static final Color[] BLOCK_COLORS = {
            Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW,
            Color.MAGENTA, Color.CYAN, Color.ORANGE, Color.PINK,
            Color.WHITE
    };

    private final int[][] world = new int[WORLD_HEIGHT][WORLD_WIDTH];

    private double playerX, playerY;
    private double playerVx, playerVy;
    private boolean onGround;
    private static final double PLAYER_WIDTH = 30;
    private static final double PLAYER_HEIGHT = 40;
    private static final double MOVE_SPEED = 250;
    private static final double JUMP_SPEED = -420;
    private static final double GRAVITY = 800;

    private int selectedSlot = 0; // 0-8 для клавиш 1-9
    private final Random random = new Random();

    public BlocksGame() {
        super(60);
        setPreferredSize(new Dimension(WORLD_WIDTH * BLOCK_SIZE, WORLD_HEIGHT * BLOCK_SIZE));
        generateWorld();
        spawnPlayer();
    }

    private void generateWorld() {
        for (int row = 0; row < WORLD_HEIGHT; row++)
            for (int col = 0; col < WORLD_WIDTH; col++)
                world[row][col] = (row >= WORLD_HEIGHT - 3) ? random.nextInt(BLOCK_COLORS.length) + 1 : 0;
    }

    private void spawnPlayer() {
        playerX = (WORLD_WIDTH * BLOCK_SIZE) / 2.0 - PLAYER_WIDTH / 2.0;
        playerY = (WORLD_HEIGHT - 4) * BLOCK_SIZE - PLAYER_HEIGHT;
        playerVx = 0; playerVy = 0; onGround = false;
        clearSpawnArea();
    }

    private void clearSpawnArea() {
        Rectangle pr = getPlayerRect();
        for (int r = 0; r < WORLD_HEIGHT; r++)
            for (int c = 0; c < WORLD_WIDTH; c++)
                if (world[r][c] != 0 && pr.intersects(new Rectangle(c*BLOCK_SIZE, r*BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE)))
                    world[r][c] = 0;
    }

    @Override
    public void keyPressed(KeyEvent e) {
        super.keyPressed(e);
        int key = e.getKeyCode();
        if (key >= KeyEvent.VK_1 && key <= KeyEvent.VK_9)
            selectedSlot = key - KeyEvent.VK_1;
    }

    @Override
    protected void update(double dt) {
        handleInput(dt);
        applyPhysics(dt);
        if (mouseLeftPressed) { destroyBlock(); mouseLeftPressed = false; }
        if (mouseRightPressed) { placeBlock(); mouseRightPressed = false; }
        if (isKeyDown(KeyEvent.VK_ESCAPE)) {
            Window window = SwingUtilities.getWindowAncestor(this);
            if (window != null)
                window.dispatchEvent(new WindowEvent(window, WindowEvent.WINDOW_CLOSING));
        }
        if (playerY > WORLD_HEIGHT * BLOCK_SIZE)
            spawnPlayer();
    }

    private void handleInput(double dt) {
        if (isKeyDown(KeyEvent.VK_A) || isKeyDown(KeyEvent.VK_LEFT))
            playerVx = -MOVE_SPEED;
        else if (isKeyDown(KeyEvent.VK_D) || isKeyDown(KeyEvent.VK_RIGHT))
            playerVx = MOVE_SPEED;
        else playerVx = 0;

        if ((isKeyDown(KeyEvent.VK_W) || isKeyDown(KeyEvent.VK_SPACE) || isKeyDown(KeyEvent.VK_UP)) && onGround) {
            playerVy = JUMP_SPEED;
            onGround = false;
        }
    }

    private void applyPhysics(double dt) {
        playerVy += GRAVITY * dt;
        playerX += playerVx * dt; resolveCollisionX();
        playerY += playerVy * dt; resolveCollisionY();
    }

    private void resolveCollisionX() {
        Rectangle pr = getPlayerRect();
        for (int r = 0; r < WORLD_HEIGHT; r++)
            for (int c = 0; c < WORLD_WIDTH; c++)
                if (world[r][c] != 0 && pr.intersects(new Rectangle(c*BLOCK_SIZE, r*BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE))) {
                    if (playerVx > 0) playerX = c*BLOCK_SIZE - PLAYER_WIDTH;
                    else if (playerVx < 0) playerX = c*BLOCK_SIZE + BLOCK_SIZE;
                    playerVx = 0;
                    pr.setRect(playerX, playerY, PLAYER_WIDTH, PLAYER_HEIGHT);
                }
    }

    private void resolveCollisionY() {
        Rectangle pr = getPlayerRect(); onGround = false;
        for (int r = 0; r < WORLD_HEIGHT; r++)
            for (int c = 0; c < WORLD_WIDTH; c++)
                if (world[r][c] != 0 && pr.intersects(new Rectangle(c*BLOCK_SIZE, r*BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE))) {
                    if (playerVy > 0) { playerY = r*BLOCK_SIZE - PLAYER_HEIGHT; playerVy = 0; onGround = true; }
                    else if (playerVy < 0) { playerY = r*BLOCK_SIZE + BLOCK_SIZE; playerVy = 0; }
                    pr.setRect(playerX, playerY, PLAYER_WIDTH, PLAYER_HEIGHT);
                }
    }

    private Rectangle getPlayerRect() {
        return new Rectangle((int)playerX, (int)playerY, (int)PLAYER_WIDTH, (int)PLAYER_HEIGHT);
    }

    private void destroyBlock() {
        int c = mousePoint.x / BLOCK_SIZE, r = mousePoint.y / BLOCK_SIZE;
        if (r>=0 && r<WORLD_HEIGHT && c>=0 && c<WORLD_WIDTH && world[r][c]!=0) world[r][c]=0;
    }

    private void placeBlock() {
        int c = mousePoint.x / BLOCK_SIZE, r = mousePoint.y / BLOCK_SIZE;
        if (r<0||r>=WORLD_HEIGHT||c<0||c>=WORLD_WIDTH||world[r][c]!=0) return;
        if (getPlayerRect().intersects(new Rectangle(c*BLOCK_SIZE, r*BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE))) return;
        world[r][c] = selectedSlot + 1;
    }

    private void drawPlayer(Graphics2D g) {
        int px = (int)playerX, py = (int)playerY;
        g.setColor(new Color(0, 120, 200));
        g.fillRoundRect(px+2, py+12, 26, 28, 8, 8);
        g.setColor(new Color(255, 220, 180));
        g.fillOval(px+7, py, 16, 16);
        g.setColor(Color.WHITE);
        g.fillOval(px+10, py+4, 5, 5);
        g.fillOval(px+17, py+4, 5, 5);
        g.setColor(Color.BLACK);
        g.fillOval(px+12, py+5, 3, 3);
        g.fillOval(px+19, py+5, 3, 3);
        g.setColor(new Color(80, 80, 80));
        g.fillRect(px+5, py+36, 8, 4);
        g.fillRect(px+17, py+36, 8, 4);
    }

    private void drawInventory(Graphics2D g) {
        int slotSize = 30, spacing = 5;
        int totalWidth = slotSize * BLOCK_COLORS.length + spacing * (BLOCK_COLORS.length - 1);
        int startX = (getWidth() - totalWidth) / 2, startY = 5;

        g.setColor(new Color(0, 0, 0, 150));
        g.fillRoundRect(startX - 8, startY - 5, totalWidth + 16, slotSize + 10, 10, 10);

        for (int i = 0; i < BLOCK_COLORS.length; i++) {
            int x = startX + i * (slotSize + spacing), y = startY;
            g.setColor(BLOCK_COLORS[i]);
            g.fillRect(x, y, slotSize, slotSize);
            g.setColor(Color.BLACK);
            g.drawRect(x, y, slotSize, slotSize);

            g.setColor(Color.WHITE);
            g.setFont(new Font("SansSerif", Font.BOLD, 12));
            String num = Integer.toString(i + 1);
            FontMetrics fm = g.getFontMetrics();
            g.drawString(num, x + (slotSize - fm.stringWidth(num))/2, y + (slotSize + fm.getAscent())/2 - 2);

            if (i == selectedSlot) {
                g.setColor(Color.WHITE);
                g.setStroke(new BasicStroke(3));
                g.drawRect(x - 1, y - 1, slotSize + 2, slotSize + 2);
                g.setStroke(new BasicStroke(1));
            }
        }
    }

    @Override
    protected void render(Graphics2D g) {
        g.setColor(new Color(135, 206, 235));
        g.fillRect(0, 0, getWidth(), getHeight());

        for (int r = 0; r < WORLD_HEIGHT; r++)
            for (int c = 0; c < WORLD_WIDTH; c++) {
                int id = world[r][c];
                if (id == 0) continue;
                g.setColor(BLOCK_COLORS[id - 1]);
                g.fillRect(c*BLOCK_SIZE, r*BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE);
                g.setColor(Color.BLACK);
                g.drawRect(c*BLOCK_SIZE, r*BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE);
            }

        int mc = mousePoint.x/BLOCK_SIZE, mr = mousePoint.y/BLOCK_SIZE;
        if (mr>=0 && mr<WORLD_HEIGHT && mc>=0 && mc<WORLD_WIDTH) {
            g.setColor(new Color(255, 255, 255, 80));
            g.fillRect(mc*BLOCK_SIZE, mr*BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE);
        }

        drawPlayer(g);
        drawInventory(g);
    }
}