import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::showMenu);
    }

    private static void showMenu() {
        JFrame menuFrame = new JFrame("blocks");
        menuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        menuFrame.setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.BLACK);
        panel.setPreferredSize(new Dimension(600, 400));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.insets = new Insets(30, 30, 30, 30);

        JLabel title = new JLabel("blocks");
        title.setFont(new Font("SansSerif", Font.BOLD, 96));
        title.setForeground(Color.WHITE);
        gbc.gridy = 0; panel.add(title, gbc);

        JButton playButton = new JButton("Играть");
        playButton.setFont(new Font("SansSerif", Font.PLAIN, 36));
        playButton.setFocusPainted(false);
        playButton.setBackground(Color.LIGHT_GRAY);
        gbc.gridy = 1; panel.add(playButton, gbc);

        menuFrame.add(panel);
        menuFrame.pack();
        menuFrame.setLocationRelativeTo(null);
        menuFrame.setVisible(true);

        playButton.addActionListener(e -> {
            menuFrame.setVisible(false);
            startGame(menuFrame);
        });
    }

    private static void startGame(JFrame menuFrame) {
        JFrame gameFrame = new JFrame("blocks");
        gameFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        gameFrame.setResizable(false);

        BlocksGame game = new BlocksGame();  // <-- было Game, стало BlocksGame
        gameFrame.add(game);
        gameFrame.pack();
        gameFrame.setLocationRelativeTo(null);
        gameFrame.setVisible(true);
        game.start();

        gameFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                game.stop();
                menuFrame.setVisible(true);
            }
        });
    }
}