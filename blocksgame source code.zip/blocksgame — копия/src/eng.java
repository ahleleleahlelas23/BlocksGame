import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashSet;
import java.util.Set;

public abstract class eng extends JPanel implements ActionListener, KeyListener, MouseListener, MouseMotionListener {

    protected final Set<Integer> pressedKeys = new HashSet<>();
    protected Point mousePoint = new Point(0, 0);
    protected boolean mouseLeftPressed = false;
    protected boolean mouseRightPressed = false;

    private final Timer timer;
    private final int fps;

    public eng(int fps) {
        this.fps = fps;
        setDoubleBuffered(true);
        setFocusable(true);
        setBackground(Color.BLACK);

        addKeyListener(this);
        addMouseListener(this);
        addMouseMotionListener(this);

        timer = new Timer(1000 / fps, this);
    }

    public void start() {
        timer.start();
        requestFocusInWindow();
    }

    public void stop() {
        timer.stop();
    }

    public boolean isKeyDown(int keyCode) {
        return pressedKeys.contains(keyCode);
    }

    protected abstract void update(double deltaTime);
    protected abstract void render(Graphics2D g);

    @Override
    public void actionPerformed(ActionEvent e) {
        update(1.0 / fps);
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        render((Graphics2D) g);
    }

    @Override public void keyPressed(KeyEvent e) { pressedKeys.add(e.getKeyCode()); }
    @Override public void keyReleased(KeyEvent e) { pressedKeys.remove(e.getKeyCode()); }
    @Override public void keyTyped(KeyEvent e) {}

    @Override public void mousePressed(MouseEvent e) {
        mousePoint = e.getPoint();
        if (SwingUtilities.isLeftMouseButton(e)) mouseLeftPressed = true;
        else if (SwingUtilities.isRightMouseButton(e)) mouseRightPressed = true;
    }
    @Override public void mouseReleased(MouseEvent e) {
        mousePoint = e.getPoint();
        if (SwingUtilities.isLeftMouseButton(e)) mouseLeftPressed = false;
        else if (SwingUtilities.isRightMouseButton(e)) mouseRightPressed = false;
    }
    @Override public void mouseClicked(MouseEvent e) {}
    @Override public void mouseMoved(MouseEvent e) { mousePoint = e.getPoint(); }
    @Override public void mouseDragged(MouseEvent e) { mousePoint = e.getPoint(); }
    @Override public void mouseEntered(MouseEvent e) {}
    @Override public void mouseExited(MouseEvent e) {}
}